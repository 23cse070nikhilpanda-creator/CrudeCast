# # from flask import Flask, request, jsonify
# # import pickle
# # import numpy as np
# # from flask_cors import CORS

# # app = Flask(__name__)
# # CORS(app)

# # # Load all models
# # models = {
# #     'arima': pickle.load(open('arima.pkl', 'rb')),
# #     'sarima': pickle.load(open('sarima.pkl', 'rb')),
# #     'lstm': pickle.load(open('lstm.pkl', 'rb')),
# #     'xgboost': pickle.load(open('xgboost.pkl', 'rb'))
# # }

# # # Load scaler (if used)
# # try:
# #     scaler = pickle.load(open('scaler.pkl', 'rb'))
# # except Exception:
# #     scaler = None


# # @app.route('/predict', methods=['POST'])
# # def predict():
# #     data = request.get_json()

# #     # Extract values
# #     prev_price = data.get('prev_price')
# #     model_name = data.get('model_name', 'xgboost').lower()

# #     # Validate input
# #     if prev_price is None:
# #         return jsonify({'error': 'Missing prev_price value'}), 400

# #     if model_name not in models:
# #         return jsonify({'error': f'Model "{model_name}" not found.'}), 400

# #     # Prepare data for prediction
# #     features = np.array([[float(prev_price)]])

# #     if scaler:
# #         features = scaler.transform(features)

# #     model = models[model_name]

# #     # Handle LSTM shape (if applicable)
# #     if model_name == 'lstm':
# #         features = features.reshape((features.shape[0], features.shape[1], 1))

# #     # Get prediction
# #     prediction = model.predict(features)

# #     # Some models (like ARIMA) may return ndarray or list
# #     if isinstance(prediction, (list, np.ndarray)):
# #         prediction = prediction[0]

# #     return jsonify({
# #         'predicted_price': float(prediction),
# #         'model_used': model_name.upper()
# #     })


# # if __name__ == '__main__':
# #     app.run(debug=True)


# from flask import Flask, request, jsonify
# import pickle
# import numpy as np
# from flask_cors import CORS

# app = Flask(__name__)
# CORS(app) # This is crucial for your browser to talk to the server

# # Load all models
# models = {
#     'arima': pickle.load(open('arima.pkl', 'rb')),
#     # 'sarima': pickle.load(open('sarima.pkl', 'rb')), # BUG 1: File is missing
#     'lstm': pickle.load(open('lstm.pkl', 'rb')),
#     'xgboost': pickle.load(open('xgboost.pkl', 'rb'))
# }

# # Load scaler (if used)
# try:
#     scaler = pickle.load(open('scaler.pkl', 'rb'))
# except Exception:
#     scaler = None


# @app.route('/predict', methods=['POST'])
# def predict():
#     data = request.get_json()

#     # Extract values
#     prev_price = data.get('prev_price')
#     model_name = data.get('model_name', 'xgboost').lower()

#     # Validate input
#     if prev_price is None:
#         return jsonify({'error': 'Missing prev_price value'}), 400

#     if model_name not in models:
#         return jsonify({'error': f'Model "{model_name}" not found.'}), 400

#     # Prepare data for prediction
#     features = np.array([[float(prev_price)]])

#     # --- BUG 2: SCALER MISMATCH ---
#     # Your scaler.pkl file expects 6 features (lag_1, lag_2, etc.)
#     # but you are only providing 1 (prev_price). This would cause a crash.
#     # We will bypass the scaler for now.
#     #
#     # if scaler:
#     #     features = scaler.transform(features) # <-- This line is the bug

#     model = models[model_name]

#     # Handle LSTM shape (if applicable)
#     if model_name == 'lstm':
#         # Reshape to [samples, timesteps, features] -> [1, 1, 1]
#         features = features.reshape((1, 1, 1))

#     # Make prediction
#     prediction = model.predict(features)

#     # Ensure prediction is a standard float for JSON
#     output_price = float(prediction[0])

#     # --- FIX 3: RETURN THE JSON YOUR SCRIPT.JS EXPECTS ---
#     return jsonify({
#         'predicted_price': output_price,
#         'model_used': model_name
#     })

# if __name__ == '__main__':
#     app.run(debug=True, port=5000)

from flask import Flask, request, jsonify
import joblib  # Using joblib for arima, xgboost, scaler
import numpy as np
from flask_cors import CORS
import tensorflow as tf
import shutil  # To copy the file
import os      # To remove the temp file

app = Flask(__name__)
CORS(app) 

print("Loading models... Please wait.")

# --- LSTM LOADING LOGIC ---
original_lstm_path = 'lstm.pkl'
temp_lstm_path = 'temp_model.keras' 
shutil.copyfile(original_lstm_path, temp_lstm_path)
lstm_model = None
try:
    lstm_model = tf.keras.models.load_model(temp_lstm_path)
    print("LSTM model loaded successfully.")
except Exception as e:
    print(f"Fatal error loading LSTM model: {e}")
finally:
    if os.path.exists(temp_lstm_path):
        os.remove(temp_lstm_path)
# --- END LSTM LOADING ---

models = {
    'arima': joblib.load('arima.pkl'),
    'xgboost': joblib.load('xgboost.pkl'),
    'lstm': lstm_model, 
    # 'sarima': joblib.load('sarima.pkl'),
}

# Scaler is still not used, as it expects 6 features
# We are bypassing it and creating features manually
try:
    scaler = joblib.load('scaler.pkl')
    print("Scaler loaded (but will be bypassed).")
except Exception:
    scaler = None
    print("Scaler not found.")

print("All models loaded.")

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    prev_price = data.get('prev_price')
    model_name = data.get('model_name', 'xgboost').lower()

    if prev_price is None:
        return jsonify({'error': 'Missing prev_price value'}), 400

    if model_name not in models:
        return jsonify({'error': f'Model "{model_name}" not found.'}), 400

    model = models[model_name]
    
    if model_name == 'lstm' and model is None:
        return jsonify({'error': 'LSTM model failed to load on server.'}), 500

    # This is the single price from the user
    price = float(prev_price)
    output_price = 0.0

    try:
        # --- THIS IS THE FIX ---
        # We now create the correct feature shape for EACH model
        
        if model_name == 'lstm':
            # LSTM expects shape [1, 12, 1]
            # We create a "fake" history of 12 timesteps, all with the same price
            features_base = np.full((12, 1), price, dtype=np.float32)
            features_lstm = features_base.reshape((1, 12, 1)) # Reshape to [samples, timesteps, features]
            
            prediction = model.predict(features_lstm)
            output_price = float(prediction[0][0]) 

        elif model_name == 'arima':
            # ARIMA is univariate and doesn't use the feature array.
            # It just forecasts the next step based on its internal state.
            prediction = model.forecast(steps=1)
            output_price = float(prediction.iloc[0]) 

        else: # XGBoost
            # XGBoost expects 5 features (based on your error)
            # We create a "fake" set of 5 features (e.g., lag1 to lag5)
            features_xgb = np.array([[price, price, price, price, price]], dtype=np.float32)
            
            prediction = model.predict(features_xgb)
            output_price = float(prediction[0])
        
        # --- END OF FIX ---

        # Return the JSON that script.js expects
        return jsonify({
            'predicted_price': output_price,
            'model_used': model_name
        })

    except Exception as e:
        print(f"Error during prediction: {e}") # For debugging
        return jsonify({'error': f'Prediction error: {str(e)}'}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)