document.addEventListener('DOMContentLoaded', () => {
  const modelNavLinks = document.querySelectorAll('#model-nav a');
  const modelTitle = document.getElementById('model-title');
  const predictionForm = document.getElementById('prediction-form');
  const resultContainer = document.getElementById('result-container');
  const predictedPriceEl = document.getElementById('predicted-price');
  const usedModelEl = document.getElementById('used-model');
  const predictBtn = document.getElementById('predict-btn');

  // Default model
  let selectedModel = 'xgboost';

  // 🔹 Change model when clicking navbar links
  modelNavLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();

      modelNavLinks.forEach(l => l.classList.remove('active'));
      link.classList.add('active');

      selectedModel = link.dataset.model;
      modelTitle.textContent = `${selectedModel.toUpperCase()} Model Prediction`;

      // Reset result area
      resultContainer.classList.add('hidden');
      predictedPriceEl.textContent = '--';
    });
  });

  // 🔹 Form submission
  predictionForm.addEventListener('submit', async (event) => {
    event.preventDefault();

    predictBtn.textContent = 'Predicting...';
    predictBtn.disabled = true;

    const prevPrice = parseFloat(document.getElementById('prev-price').value);

    const featureData = {
      prev_price: prevPrice,
      model_name: selectedModel
    };

    try {
      const response = await fetch('http://127.0.0.1:5000/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(featureData)
      });

      if (!response.ok) throw new Error(`HTTP Error ${response.status}`);

      const result = await response.json();
      predictedPriceEl.textContent = `$${result.predicted_price.toFixed(2)} per barrel`;
      usedModelEl.textContent = `Model used: ${result.model_used}`;
      resultContainer.classList.remove('hidden');

    } catch (error) {
      predictedPriceEl.textContent = 'Error fetching prediction.';
      resultContainer.classList.remove('hidden');
      console.error(error);
    } finally {
      predictBtn.textContent = 'Predict';
      predictBtn.disabled = false;
    }
  });
});
