document.addEventListener('DOMContentLoaded', () => {
    const predictionForm = document.getElementById('prediction-form');
    const resultContainer = document.getElementById('result-container');
    const predictedPriceEl = document.getElementById('predicted-price');
    const predictBtn = document.getElementById('predict-btn');

    predictionForm.addEventListener('submit', async (event) => {
        // Prevent the page from reloading
        event.preventDefault();

        // Show a loading state
        predictBtn.textContent = 'Predicting...';
        predictBtn.disabled = true;

        // 1. Get the single input value from the form
        const prevPrice = document.getElementById('prev-price').value;

        const featureData = {
            // This is the only feature your backend needs now
            prev_price: parseFloat(prevPrice) 
        };

        // 2. Call your backend API
        try {
            const response = await fetch('http://127.0.0.1:5000/predict', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(featureData)
            });

            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const result = await response.json();
            const prediction = result.predicted_price;

            // 3. Display the result
            predictedPriceEl.textContent = `$${prediction.toFixed(2)} per barrel`;
            resultContainer.classList.remove('hidden');

        } catch (error) {
            // Handle any errors that occurred during the fetch
            predictedPriceEl.textContent = 'Error: Could not get prediction.';
            resultContainer.classList.remove('hidden');
            console.error("Prediction Error:", error);
        } finally {
            // Reset the button
            predictBtn.textContent = 'Predict Price';
            predictBtn.disabled = false;
        }
    });
});